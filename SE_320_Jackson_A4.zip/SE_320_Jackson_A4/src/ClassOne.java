import java.util.*;

public class ClassOne {
	public static void main(String args[]) {
		Set<String> s1 = new LinkedHashSet<String>();
		Set<String> s2 = new LinkedHashSet<String>();
		Set<String> r = new LinkedHashSet<String>();
		s1.add("George");
		s1.add("Jim");
		s1.add("John"); 
		s1.add("Blake");
		s1.add("Kevin"); 
		s1.add("Michael");
		System.out.print("Set 1: ");
		System.out.println(s1);
		
		s2.add("George");
		s2.add("Katie");
		s2.add("Kevin");
		s2.add("Michelle");
		s2.add("Ryan");
		System.out.print("Set 2: ");
		System.out.println(s2);
		
		r.addAll(s1); //Union
		r.addAll(s2);
		System.out.print("Union of the two sets: ");
		System.out.println(r);
		
		r.clear(); //remake the temp set
		r.addAll(s1); //Difference of two sets
	
		for(String t: s2)
		{
			if(r.contains(t))
				r.remove(t);
			else
				r.add(t);
		}
		System.out.print("Difference of the two sets: ");
		System.out.println(r);
		
		
		r.clear(); //remake the temp set
		r.addAll(s1); //Intersection of two sets
		
		s1.retainAll(s2);
		
		System.out.print("Intersection of the two sets: ");
		System.out.println(s1);
	}


}
